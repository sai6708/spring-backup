import java.util.Scanner;

public class Charstr {

	
		static int extractInt(String str) 
		{ 
			
			str = str.replaceAll("[^\\d]", " "); 
			int sum=0;
			
			str = str.trim(); 
			
			str = str.replaceAll(" ", ""); 		
			

			if (str.equals("")) 
				return sum; 
			
			
			for (char c : str.toCharArray()) {
				sum = sum +  Integer.parseInt(String.valueOf(c)); 
			}

			return sum; 
		} 
		
		static String extractStr(String str) 
		{ 
			
			str = str.replaceAll("[0-9]", " "); 

			
			str = str.trim(); 

			 
			str = str.replaceAll(" ", ""); 			
			 

			if (str.equals("")) 
				return "-1"; 

			return str; 
		} 

		
		public static void main(String[] args) 
		{ 
			Scanner s =  new Scanner(System.in);
			System.out.println("input1=");
			String str = s.nextLine();			
			System.out.println("input2=");
			int str2 = s.nextInt();
			
			if(str2==1)
			{
				System.out.print(extractStr(str)); 
			}else{
				System.out.print(extractInt(str)); 
			}
			
		} 

}
