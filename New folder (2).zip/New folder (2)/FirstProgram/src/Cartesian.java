import java.util.*;

public class Cartesian {
	@SuppressWarnings("null")
	public static void main(String[] args){
		
		String   firstarr[] ={"1","2"}, secoarr[] ={"3","4"}; 
	    String finalarr ="";
			
		
		
	
		for(String a:firstarr)
		{
			for(String b:secoarr)
			{
				finalarr = finalarr + a+b + ",";
				
			}
			
		}
		
		System.out.println(Arrays.deepToString(finalarr.split(",")));
		
	}

}
