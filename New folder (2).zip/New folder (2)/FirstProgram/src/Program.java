
import java.util.Scanner;
import java.lang.Math;

class LoanCalculator {
    float loanAmount;
    float months;
    int n1;
}
final class display extends LoanCalculator
{
    public double EmiCal(float loanAmount,float months, int n1)
    {
        double n2 = 1200;
        double k = n1/n2;
        double i = (Math.pow((1+k),months)/(Math.pow((1+k),months)-1));
        double emical = loanAmount * k * i ;
        return emical;
    }
}

class Program {
	public static void main(String[] args) {
        Scanner Scan = new Scanner(System.in);
        System.out.println("Enter Loan Amount: ");
        float loanAmount = Scan.nextFloat();
        System.out.println("Enter number of months: ");
        float months = Scan.nextFloat();
        System.out.println("Enter the Rate of Interest: ");
        int n1 = Scan.nextInt();
        display loancal = new display();
        double emi = loancal.EmiCal(loanAmount , months, n1);
        System.out.print("EMI to be paid per month: "+ emi);

    }
}