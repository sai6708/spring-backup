import java.util.*;
import java.util.stream.Collectors;

public class cartesian {
  public static void main(String[] args){
	  List<String> a = Arrays.asList("a", "b", "c");
	    List<String> b = Arrays.asList("d", "e");
	    String[] AB = a.stream().flatMap(ai -> b.stream().map(bi -> new String[] { ai+""+ bi })).toArray(String[]::new);
	    System.out.println(Arrays.deepToString(AB));
  }
}
