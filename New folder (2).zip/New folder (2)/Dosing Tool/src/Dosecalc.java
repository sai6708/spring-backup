  
import java.util.HashMap;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFSheet; 
import org.apache.poi.ss.usermodel.Row; 

public class Dosecalc {
	
	static  HSSFSheet dose_sheet;
	static  HashMap<String, String> replacestring ; 
	 Dosecalc() {
		 String temp_replace_char="";
		 replacestring = new HashMap<String, String>();
		 dose_sheet=Excelhandler.wb.getSheetAt(1);
		
		for(Row drow: dose_sheet)    
		{
			if(drow.getRowNum()>0 && drow.getCell(3) != null)
			{				
				temp_replace_char = (drow.getCell(2) == null?temp_replace_char:drow.getCell(2).toString());
				replacestring.put(temp_replace_char, drow.getCell(3).toString());
			}
		}
	
	}
	 
	 public void doseform(String treat, int visit) {
		
		 String temp_quantity1;
		 
		 for (String key : replacestring.keySet()) {
			 System.out.println(key);
			  if(Excelhandler.temp_Dose_level.contains("_"+key+"_") )
			  {
				  //System.out.println("_"+key+"_");
				  for(String a:replacestring.get(key).split(",")){
					  
					  temp_quantity1=Excelhandler.temp_quantity;
					  if (Excelhandler.temp_quantity.equals(key))
					  {
						  temp_quantity1 = a;
					  }
					  System.out.println(treat+" "+Excelhandler.split_visit[visit]+" "+Excelhandler.temp_Dose_level.replace("_"+
							  key+"_", "_"+a+"_")+" "+temp_quantity1+" "+Excelhandler.temp_pack_type);
				  }
			  }
		 }
		 
		 
	}

}
