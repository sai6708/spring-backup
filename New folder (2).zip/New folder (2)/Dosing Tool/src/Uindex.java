import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JRadioButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;

import java.awt.Toolkit;
import java.awt.TextField;
import java.awt.Label;
import java.awt.TextArea;
import java.awt.Button;
import java.awt.event.ActionListener;

import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.JLayeredPane;
import javax.swing.JTextArea;
import java.awt.CardLayout;


public class Uindex {

	private JFrame frmDosingTool;

	/**
	 * Launch the application.
	 */
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Uindex window = new Uindex();
					window.frmDosingTool.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Uindex() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	
	private void initialize() {
		frmDosingTool = new JFrame();
		frmDosingTool.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\thatiks\\Downloads\\dose icon.png"));
		//frmDosingTool.setOpacity(0.1f)
javax.swing.JCheckBox checkBox = new javax.swing.JCheckBox("Is pack type and quantity combined");;
		frmDosingTool.setTitle("Dosing Tool");
		frmDosingTool.setBounds(100, 100, 741, 565);
		frmDosingTool.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmDosingTool.getContentPane().setLayout(null);
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("Is pack type and quantity combined");
		chckbxNewCheckBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (chckbxNewCheckBox.isSelected()) {		 
					Excelhandler.combine_flag = 1;
				 
				} else {				 
					Excelhandler.combine_flag = 0;
				 
				}
			}
		});
		
		
		chckbxNewCheckBox.setBounds(42, 226, 305, 29);
		frmDosingTool.getContentPane().add(chckbxNewCheckBox);
		
		TextField filetextField = new TextField();
		filetextField.setEnabled(false);
		filetextField.setEditable(false);
		filetextField.setBounds(42, 102, 486, 27);
		frmDosingTool.getContentPane().add(filetextField);
		
		Label label = new Label("Choose File");
		label.setBounds(42, 64, 187, 27);
		frmDosingTool.getContentPane().add(label);
		
		Button button = new Button("Browse");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JFileChooser jfc= new JFileChooser();
				jfc.showOpenDialog(null);
				filetextField.setText(jfc.getSelectedFile().getAbsolutePath());
				Excelhandler.filename = jfc.getSelectedFile().getAbsolutePath();
			}
		});
		button.setBounds(561, 102, 91, 27);
		frmDosingTool.getContentPane().add(button);
		
		JCheckBox chckbxHaveDoseCalculations = new JCheckBox("Have Dose Calculations");
		chckbxHaveDoseCalculations.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (chckbxNewCheckBox.isSelected()) {		 
					Excelhandler.dose_calculations = 1;
				 
				} else {				 
					Excelhandler.dose_calculations = 0;
				 
				}
			}
		});
		chckbxHaveDoseCalculations.setBounds(42, 263, 305, 29);
		frmDosingTool.getContentPane().add(chckbxHaveDoseCalculations);
		
		Button button_1 = new Button("Next");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(filetextField.getText().length()<1)
				{
					JOptionPane.showMessageDialog(null, "File path cannot be empty");
				}
				else
				{
					//frmDosingTool.dispose();
					
					Excelhandler exc =  new Excelhandler();
					
					try {
						exc.readandmakedata();
						JOptionPane.showMessageDialog(null, "Done");
					} catch (Exception e2) {
						
						JOptionPane.showMessageDialog(null, e2);
					}
				}
			
				
			}
		});
		button_1.setBounds(561, 443, 91, 29);
		frmDosingTool.getContentPane().add(button_1);
		
		JCheckBox chckbxNewCheckBox_1 = new JCheckBox("Is visit and visit descrition combined");
		chckbxNewCheckBox_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (chckbxNewCheckBox_1.isSelected()) {		 
					Excelhandler.vd_combine_flag = 1;
				 
				} else {				 
					Excelhandler.vd_combine_flag = 0;
				 
				}
			}
		});
		chckbxNewCheckBox_1.setBounds(42, 196, 230, 18);
		frmDosingTool.getContentPane().add(chckbxNewCheckBox_1);
	}
}
