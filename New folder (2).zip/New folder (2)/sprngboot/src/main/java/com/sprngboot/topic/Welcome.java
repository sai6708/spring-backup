package com.sprngboot.topic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class Welcome{
 public static void main(String[] args) {
       SpringApplication.run(Welcome.class, args);
    }
}