package com.sprngboot.topic;


import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class Topics {
	
	@Id
	private String topic;
	private String course_dura;
	
	public Topics(){
		
	}
	
	public Topics(String topic,String course_dura)
	{
		super();
		this.topic = topic;
		this.course_dura = course_dura;
	}
	
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public String getCourse_dura() {
		return course_dura;
	}
	public void setCourse_dura(String course_dura) {
		this.course_dura = course_dura;
	}

}
