package com.sprngboot.topic;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.sprngboot.topic.Topics;
import java.util.List;

@RestController
public class Messagewelm {
	
	@Autowired
	private Topicservices tss;
	
	@RequestMapping("/hey") 
	public String wlcmes() {
		return "Hi, how u doing";
		
	}
	
	@RequestMapping(method = RequestMethod.GET,value="/topics")
	public List<Topics> Listoftopics() {
		System.out.println("Hey how's it going cool");
		return tss.gettopics();
		
	}
	
	@RequestMapping("/topics/{topicname}")
	public Topics topic(@PathVariable String topicname) {
		
		return tss.gettopicspecfic(topicname);
		
	}
	
	@RequestMapping(method = RequestMethod.POST,value="/topics")
	public void addtopic(@RequestBody Topics topicname) {		
		 tss.addtopic(topicname);		
	}
	
	@RequestMapping(method = RequestMethod.PUT,value="/topics/{topicname}")
	public void Updatetopic(@RequestBody Topics topic,@PathVariable("topicname") String id) {		
		 tss.updatetopic(id, topic);		
	}
	
	@RequestMapping(method = RequestMethod.DELETE,value="/topics/{topicname}")
	public void deletetopic(@PathVariable("topicname") String id) {		
		 tss.deletetopic(id);		
	}
}
