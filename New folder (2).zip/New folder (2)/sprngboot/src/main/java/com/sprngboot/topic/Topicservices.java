package com.sprngboot.topic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Topicservices {
	
	@Autowired
	private TopicRepository topicRepository;
	
	private List<Topics> topicslist = (List<Topics>) new ArrayList<>(Arrays.asList(new Topics("Java","30 days"),
																	new Topics("JSP","20 days"),
																	new Topics("Spring","41 days"))
			);
	
	
	public List<Topics> gettopics() {
		//return topicslist;
		List<Topics> topics =  new ArrayList<>();
		topicRepository.findAll().forEach(topics::add);
		return topics;
	}
	
	public Topics gettopicspecfic(String topic)
	{
		return topicslist.stream().filter(p -> p.getTopic().equals(topic)).findFirst().get();
	}

	public void addtopic(Topics topicname) {
		// TODO Auto-generated method stub
		//topicslist.add(topicname);	
		topicRepository.save(topicname);
	}

	public void updatetopic(String id, Topics topic) {
		/*Topics t;
		for(int i=0;i<topicslist.size();i++){
			t = topicslist.get(i);
			if(t.getTopic().equals(id)){
				topicslist.set(i, topic);
				return;
			}
		}*/
		
	}

	public void deletetopic(String id) {
		/*topicslist.removeIf(f -> f.getTopic().equals(id));
		return;
		*/
	}

}
