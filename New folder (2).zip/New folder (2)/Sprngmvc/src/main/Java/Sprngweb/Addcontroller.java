package com.sait.Sprngweb;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Addcontroller {
	
	
	public ModelAndView register(@RequestParam("firstname") String fname, @RequestParam("lastname") String lname){
		
		ModelAndView mv= new ModelAndView();
		mv.addObject("result","Hi "+fname+" "+lname+", <br>Thank you :)"  );
		mv.setViewName("result.jsp");
		
		return mv;
	}

}
