
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;

import java.awt.CardLayout;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JTextArea;
import java.awt.Color;
import javax.swing.JInternalFrame;
import javax.swing.JSplitPane;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Font;
import java.awt.Toolkit;

public class Uindex extends JFrame {

	private JPanel contentPane;
	private JTextField filetextField;
	static JTextArea resultoutput;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Uindex frame = new Uindex();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Uindex() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("dose icon.png")));
		setTitle("Dosing Tool V1        \u00A9 copyright-2020 Sai Thatikonda");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 885, 696);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLayeredPane layeredPane = new JLayeredPane();
		layeredPane.setBounds(10, 21, 849, 576);
		contentPane.add(layeredPane);
		layeredPane.setLayout(new CardLayout(0, 0));
		
		final JPanel firstscreen = new JPanel();
		layeredPane.add(firstscreen, "name_15960160341484");
		firstscreen.setLayout(null);
		
		final JPanel secondscreen = new JPanel();
		layeredPane.add(secondscreen, "name_15964400274124");
		secondscreen.setLayout(null);
		
		JButton btnNewButton_2 = new JButton("Back");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				firstscreen.setVisible(true);
				secondscreen.setVisible(false);
				
				
			}
		});
		btnNewButton_2.setBounds(10, 16, 89, 29);
		secondscreen.add(btnNewButton_2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 61, 849, 515);
		secondscreen.add(scrollPane);
		
		resultoutput = new JTextArea();
		resultoutput.setEditable(false);
		resultoutput.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 15));
		scrollPane.setViewportView(resultoutput);
		resultoutput.setWrapStyleWord(true);
		
		JButton btnNewButton_3 = new JButton("Save");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(resultoutput.getText().length()>0)
				{
					try {
						
						int result = JOptionPane.showConfirmDialog(null, "I Agree, am responsible of data", "Aggrement", JOptionPane.YES_NO_OPTION);
						if (result == JOptionPane.YES_OPTION)
						{
							JFileChooser fileChooser = new JFileChooser();
							fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
							fileChooser.setDialogTitle("Specify a file to save");   
							fileChooser.showSaveDialog(null);
							//JOptionPane.showMessageDialog(null, fileChooser.getSelectedFile()+"\\Mastvis_auto_generated.csv");
							FileWriter   myWriter = new FileWriter (new File(fileChooser.getSelectedFile()+"\\Mastvis_auto_generated.csv"));					
							resultoutput.write(myWriter);
							myWriter.close();
							if(Excelhandler.mtrt_flag==1){
								FileWriter mtrtwriter = new FileWriter (new File(fileChooser.getSelectedFile()+"\\MTRTPAK.csv")); 
								for(String str: Excelhandler.mtrtcsv) {
									mtrtwriter.write(str + System.lineSeparator());
								}
								mtrtwriter.close();
							}							
							JOptionPane.showMessageDialog(null, " File saved");
						}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						JOptionPane.showMessageDialog(null, e +": Error saving file");
					}
				}
				else{
					JOptionPane.showMessageDialog(null, " No data generated");
				}
				
			}
		});
		btnNewButton_3.setBounds(735, 16, 89, 27);
		secondscreen.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Generate");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				resultoutput.setText("");
				Excelhandler exc =  new Excelhandler();
				Excelhandler.sequnce=0;
				try {						
					exc.readandmakedata();
					JOptionPane.showMessageDialog(null, "Data generation completed!");
				} catch (Exception e2) {					
					JOptionPane.showMessageDialog(null, e2);
				}
			}
		});
		btnNewButton_4.setBounds(126, 16, 115, 29);
		secondscreen.add(btnNewButton_4);
		
		final JCheckBox chckbxNewCheckBox_3 = new JCheckBox("MTRTPAK CSV");
		chckbxNewCheckBox_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (chckbxNewCheckBox_3.isSelected()) {		 
					Excelhandler.mtrt_flag = 1;
				 
				} else {				 
					Excelhandler.mtrt_flag = 0;
				 
				}
			}
		});
		chckbxNewCheckBox_3.setBounds(284, 16, 188, 29);
		secondscreen.add(chckbxNewCheckBox_3);
		
		
		JLabel lblNewLabel = new JLabel("Choose File");
		lblNewLabel.setBounds(61, 65, 127, 20);
		firstscreen.add(lblNewLabel);
		
		filetextField = new JTextField();
		filetextField.setFont(new Font("Tahoma", Font.BOLD, 11));
		filetextField.setEditable(false);
		filetextField.setBounds(61, 98, 563, 20);
		firstscreen.add(filetextField);
		filetextField.setColumns(10);
		
		JButton btnNewButton = new JButton("Browse");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser jfc= new JFileChooser();
				jfc.showOpenDialog(null);
				filetextField.setText(jfc.getSelectedFile().getAbsolutePath());
				Excelhandler.filename = jfc.getSelectedFile().getAbsolutePath();
			}
		});
		btnNewButton.setBounds(645, 97, 97, 23);
		firstscreen.add(btnNewButton);
		
		final JCheckBox chckbxNewCheckBox = new JCheckBox("Is visit and visit descrition combined");
		chckbxNewCheckBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (chckbxNewCheckBox.isSelected()) {		 
					Excelhandler.vd_combine_flag = 1;
				 
				} else {				 
					Excelhandler.vd_combine_flag = 0;
				 
				}
			}
		});
		chckbxNewCheckBox.setBounds(61, 153, 417, 18);
		firstscreen.add(chckbxNewCheckBox);
		
		final JCheckBox chckbxNewCheckBox_1 = new JCheckBox("Is pack type and quantity combined");
		chckbxNewCheckBox_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (chckbxNewCheckBox_1.isSelected()) {		 
					Excelhandler.combine_flag = 1;
				 
				} else {				 
					Excelhandler.combine_flag = 0;
				 
				}
			}
		});
		chckbxNewCheckBox_1.setBounds(61, 186, 326, 23);
		firstscreen.add(chckbxNewCheckBox_1);
		
		final JCheckBox chckbxNewCheckBox_2 = new JCheckBox("Dose Decoding");
		chckbxNewCheckBox_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (chckbxNewCheckBox_2.isSelected()) {		 
					Excelhandler.dose_calculations = 1;
				 
				} else {				 
					Excelhandler.dose_calculations = 0;
				 
				}
			}
		});
		chckbxNewCheckBox_2.setBounds(61, 226, 370, 23);
		//firstscreen.add(chckbxNewCheckBox_2);
		
		JButton btnNewButton_1 = new JButton("Next");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(filetextField.getText().length()<1)
				{
					JOptionPane.showMessageDialog(null, "File path cannot be empty");
				}
				else
				{
					//frmDosingTool.dispose();
					
					firstscreen.setVisible(false);
					secondscreen.setVisible(true);
					resultoutput.setText("");
					
				}
			}
		});
		btnNewButton_1.setBounds(695, 397, 89, 23);
		firstscreen.add(btnNewButton_1);
		
		
	}
}
