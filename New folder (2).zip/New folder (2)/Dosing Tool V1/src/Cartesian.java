public class Cartesian {
  
	public String[] dataset_make(String[] fa, String[] sb){
				
		String finalarr="";
		Boolean flag = true;
		
		for(String a:fa)
		{
			for(String b:sb)
			{
				flag = true;
			
				
				if(flag)
				{
					finalarr = finalarr + a+'*'+b + ",";
				}
				
				
			}
			
		}
		
		return finalarr.split(",");
	}
}
