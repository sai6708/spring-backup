
import java.util.Arrays;
import java.util.HashMap;
import java.util.TreeMap;

import org.apache.poi.hssf.usermodel.HSSFSheet;  
import org.apache.poi.ss.usermodel.Row; 

public class Dosecalc {
	
	static  HSSFSheet dose_sheet;
	static  HashMap<String, String> replacestring ; 
	static  TreeMap<Integer, String> current_keys;
	String  temp_keys_dataset[], temp_dose_final;
	static Integer choose_by=0;
	private static Cartesian cart;
	 Dosecalc() {
		 String temp_replace_char="", temp_chooseby_value="";
		 replacestring = new HashMap<String, String>();
		 dose_sheet=Excelhandler.wb.getSheetAt(1);
		 current_keys = new TreeMap<Integer, String>();
		 cart = new Cartesian();
		for(Row drow: dose_sheet)    
		{
			if(drow.getRowNum()>0 && drow.getCell(3) != null)
			{				
				temp_replace_char = (drow.getCell(2) == null?temp_replace_char:drow.getCell(2).toString());
				if(choose_by==1)
				{
					temp_chooseby_value = (drow.getCell(1) == null?temp_chooseby_value:drow.getCell(1).toString());
					temp_replace_char = temp_chooseby_value +"^^"+ temp_replace_char;
				}				
				replacestring.put(temp_replace_char, drow.getCell(3).toString());
			}
		}
	
	}
	 
	 public void doseform(String treat, int visit) {
		
		 String temp_quantity1, temp_key;
		
		 current_keys.clear();
		 for (String key : replacestring.keySet()) {
			 System.out.println(key);
			 
			  if(choose_by==1 && key.split("\\^\\^")[0].equals(Excelhandler.temp_treat_group))
			  {
				  key =key.split("\\^\\^")[1];
				  System.out.println(key);
			  }
			  
			  if(Excelhandler.temp_Dose_level.contains(key+"") )
			  {				  
				  current_keys.put(Excelhandler.temp_Dose_level.indexOf(key+""), key);	 
			  }
			 
		 }
		
		 if(current_keys.size()==1)
		 {
			 temp_key = current_keys.entrySet().iterator().next().getValue();
			 for(String a:replacestring.get((choose_by==1?Excelhandler.temp_treat_group+"^^":"")+temp_key).split(",")){
				  
				  temp_quantity1=Excelhandler.temp_quantity;
				  if (Excelhandler.temp_quantity.equals(temp_key))
				  {
					  temp_quantity1 = a;
				  }
				  Uindex.resultoutput.append(Excelhandler.split_visit[visit]+",\""+treat+"\","+"\""+Excelhandler.temp_Dose_level.replace(
						  ""+temp_key, ""+a)+"\",\""+Excelhandler.temp_pack_type+"\","+temp_quantity1+","+temp_quantity1+",\""+Excelhandler.temp_Consecutive+"\","+
						  (Excelhandler.sequnce+=1)+",\""+Excelhandler.temp_visit_comment+"\"\n");
				  
				  if(!Excelhandler.mtrtcsv.contains("\""+treat+"\",\""+Excelhandler.temp_pack_type+"\""))
					{
					  Excelhandler.mtrtcsv.add("\""+treat+"\",\""+Excelhandler.temp_pack_type+"\""); 
					}
			  
				
			  }
		 }
		 else if(current_keys.size()>1)
		 {			 
			 
			 //System.out.println(current_keys.values());
			 for(int roll=0;roll<current_keys.size()-1;roll++)
			 {
				 if(temp_keys_dataset == null)
				 {
					 temp_keys_dataset = replacestring.get((choose_by==1?Excelhandler.temp_treat_group+"^^":"")+current_keys.values().toArray()[roll]).split(",");
					
				 }				
			
				 temp_keys_dataset = cart.dataset_make(temp_keys_dataset, replacestring.get((choose_by==1?Excelhandler.temp_treat_group+"^^":"")+current_keys.values().toArray()[roll+1]).split(","));
			 }
			 //System.out.println(Arrays.deepToString(temp_keys_dataset));
			 		
			
			 for(String bullet:temp_keys_dataset)
			 {				 
				 temp_dose_final = Excelhandler.temp_Dose_level;
				 temp_quantity1=Excelhandler.temp_quantity;
				 for(int target=0;target<current_keys.size();target++)
				 {
					  if (Excelhandler.temp_quantity.equals(current_keys.values().toArray()[target]))
					  {
						  temp_quantity1 = bullet.split("\\*")[target]+"";
					  }
					 temp_dose_final = temp_dose_final.replace(""+current_keys.values().toArray()[target], ""+bullet.split("\\*")[target]);
				 }
				 Uindex.resultoutput.append(Excelhandler.split_visit[visit]+",\""+treat+"\","+"\""+temp_dose_final
						 +"\",\""+Excelhandler.temp_pack_type+"\","+temp_quantity1+","+temp_quantity1+",\""+Excelhandler.temp_Consecutive+"\","+
						  (Excelhandler.sequnce+=1)+",\""+Excelhandler.temp_visit_comment+"\"\n");
				 
				 if(!Excelhandler.mtrtcsv.contains("\""+treat+"\",\""+Excelhandler.temp_pack_type+"\""))
					{
					  Excelhandler.mtrtcsv.add("\""+treat+"\",\""+Excelhandler.temp_pack_type+"\""); 
					}
			 }
			 temp_keys_dataset = null;
		 }
		 else
		 {
			 Uindex.resultoutput.append("No Suitable replacable Characters found\n");
		 }
		 
	}

	

}
