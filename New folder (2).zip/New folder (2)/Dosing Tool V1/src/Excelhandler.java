import java.io.File;  
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFSheet;  
import org.apache.poi.hssf.usermodel.HSSFWorkbook;  
 
import org.apache.poi.ss.usermodel.Row;  
 

public class Excelhandler {
	
	static String temp_treat="", temp_treat_group ="", temp_Visit_num="", temp_Consecutive="", temp_pack_type="", temp_Visit_num1[],  Visit_num,
			temp_quantity="", temp_Dose_level= "", temp_visit_comment ="", split_treat[], split_visit[], split_comment[], filename, temp_pack_type2[];
	static String[][] temp_records;
	static Integer combine_flag=0, dose_calculations=0, vd_combine_flag=0, sequnce=0, mtrt_flag=0;
	static FileInputStream fis;
	static HSSFWorkbook wb;
	static Dosecalc dc;
	static List<String> mtrtcsv = new ArrayList<String>();  
	
	
	public void readandmakedata() throws IOException  
	{
		
		
		fis=new FileInputStream(new File(filename));  		
		wb=new HSSFWorkbook(fis);  
		HSSFSheet sheet= wb.getSheetAt(0);
		//FormulaEvaluator formulaEvaluator=wb.getCreationHelper().createFormulaEvaluator();  
		if (dose_calculations==1)
		{
			dc = new Dosecalc();
		}
		
		
		Uindex.resultoutput.append("\"VISIT_NUM\",\"TREAT_GROUP\",\"DOSE_LEVEL\",\"PACK_TYPE\",\"QUANTITY\",\"MIN_QUANTITY\",\"CONSECUTIVE\",\"SEQUENCE\",\"VISIT_COMMENT\"\n");
		//myWriter.println("\"VISIT_NUM\",\"TREAT_GROUP\",\"DOSE_LEVEL\",\"PACK_TYPE\",\"QUANTITY\",\"MIN_QUANTITY\",\"CONSECUTIVE\",\"SEQUENCE\",\"VISIT_COMMENT\"");
		mtrtcsv.add("\"TREAT_GROUP\",\"PACK_TYPE\""); 
		for(Row row: sheet)     //iteration over row using for each loop  
		{			
			
			if(row.getRowNum()>0 )
			{
				temp_treat = row.getCell(0)== null?"":row.getCell(0).toString();
				
				if(!temp_treat.equals("N") && !temp_treat.equals("N/A"))
				{
					temp_treat_group = (temp_treat == ""?temp_treat_group:temp_treat);
					Visit_num = (row.getCell(1) == null?Visit_num:row.getCell(1).toString());					
					temp_Dose_level = (row.getCell(2) == null?temp_Dose_level: row.getCell(2).toString().split("\\.")[0]);
					temp_Consecutive = (row.getCell(3) == null || row.getCell(3).toString().length() == 0 ?temp_Consecutive:row.getCell(3).toString());
					temp_pack_type = (row.getCell(4) == null?"N":row.getCell(4).toString());
					if(combine_flag==1)
					{						

						temp_pack_type2 = (temp_pack_type.indexOf(" X ")>0?temp_pack_type.split(" X "):temp_pack_type.split(" x "));
						
						if (temp_pack_type2[1].length() < temp_pack_type2[0].length())
						{
							temp_pack_type = temp_pack_type2[0];
							temp_quantity = temp_pack_type2[1];
						}else{
							temp_pack_type = temp_pack_type2[1];
							temp_quantity = temp_pack_type2[0];
						}
						
						
					}
					else{
						
						temp_quantity = row.getCell(5).toString().split("\\.")[0];
					}
					if(vd_combine_flag==1 && Visit_num.split(",").length>1)
					{
						temp_Visit_num = ""; temp_visit_comment = "";
						for(int looper=0;looper<Visit_num.split(",").length;looper++)
						{
							temp_Visit_num1 = 	Visit_num.split(",")[looper].split(" - ");
							temp_Visit_num = temp_Visit_num+","+temp_Visit_num1[0];	
							temp_visit_comment = temp_visit_comment+","+temp_Visit_num1[1];
							
							if(looper==0)
							{
								temp_Visit_num = temp_Visit_num1[0];	
								temp_visit_comment = temp_Visit_num1[1];
							}
						}
					}
					else if (vd_combine_flag==1)
					{
						temp_Visit_num1 = 	Visit_num.split(" - ");		
						temp_Visit_num = temp_Visit_num1[0];						
						temp_visit_comment = temp_Visit_num1[1];
					}
					else
					{
						temp_Visit_num = Visit_num.split("\\.")[0];
						temp_visit_comment = (row.getCell(6) == null?temp_visit_comment:row.getCell(6).toString());
					}
					
					
					//temp_Visit_num = temp_Visit_num.valueOf((int) (double) temp_Visit_num)
					
					MRBString();
				}

			}
				
		}
		//myWriter.close();
	}
	
	public static void MRBString() // make or break string method
	{
		split_treat = temp_treat_group.split(",");
		split_visit = temp_Visit_num.split(",");
		split_comment = temp_visit_comment.split(",");
		
		String mastvis="true", visit_packs="true";
		
		for(String w:split_treat){
			
			for(int x=0;x<split_visit.length;x++)
			{
				if (dose_calculations==1)
				{
					dc.doseform(w,x);
				}
				else{
					 
					/*if(split_visit[x].equals(2))
					{
						visit_packs="false";
					}*/
					
					//Uindex.resultoutput.append(split_visit[x]+",\""+w+"\","+temp_Dose_level+",\""+temp_pack_type+"\","+temp_quantity+","+temp_quantity+
				                       //   ","+"\""+temp_Consecutive+"\","+(sequnce+=1)+",\""+split_comment[x]+"\"\n");
					if(!mtrtcsv.contains("\""+w+"\",\""+temp_pack_type+"\""))
					{
						mtrtcsv.add("\""+w+"\",\""+temp_pack_type+"\""); 
					}
				  
				   Uindex.resultoutput.append("GoSub InsertTables_CSV('"+split_visit[x]+"','"+w+"','"+temp_Dose_level+"','"+temp_pack_type+"','"+temp_quantity+"','"+
							temp_quantity+"','N',"+mastvis+","+visit_packs+")\n");
					   					   
				}
				
			}
			
		} 
		
		
	}

}
