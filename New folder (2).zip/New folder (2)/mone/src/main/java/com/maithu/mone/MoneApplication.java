package com.maithu.mone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoneApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoneApplication.class, args);
	}

}
