package com.maithu.mone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoneApplicationTests {

	@Test
	void contextLoads() {
	}

}
