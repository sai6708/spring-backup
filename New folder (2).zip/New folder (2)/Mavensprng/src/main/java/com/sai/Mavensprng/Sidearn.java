package com.sai.Mavensprng;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.stereotype.Component;

@Component
public class Sidearn implements Earnings{
	
	private String way;	
	private Income sal; 

	public void setSal(Income sal) {
		this.sal = sal;
	}
	
	/*public Sidearn(String way)
	{
		this.way = way;
	}*/
	
	public void getsource()
	{
		System.out.println("now you are earning through side work "+way+" salary of ruppess "+sal.getSalary());
	}

	/*public void destroy() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("thats ok");
	}
*/

}
