package com.sai.Mavensprng;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args ) {
    	
    	ApplicationContext cont = new ClassPathXmlApplicationContext("Beanobjs.xml");
        System.out.println( "Hello World!" );
        Jobearn money = (Jobearn) cont.getBean("jobearn");
        money.getsource();        
        
    }
}
