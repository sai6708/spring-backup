package com.sai.Mavensprng;


public interface Earnings {
	
	void getsource();

}
