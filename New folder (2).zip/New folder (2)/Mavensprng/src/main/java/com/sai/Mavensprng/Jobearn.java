package com.sai.Mavensprng;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Jobearn implements Earnings{	
	
	private String company;	
	@Autowired
	private Income sal; 

	public String getCompany() {
		return company;
	} 

	public void setCompany(String company) {
		this.company = company;
	}	


	public void setSal(Income sal) {
		this.sal = sal;
	}
	
	public void getsource()
	{
		System.out.println("now you are earning through job from "+getCompany()+" salary of ruppess "+sal.getSalary());
		
	}

}