package com.maithu.springboothiber;


import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;






@Entity
public class Topics {
	
	@Id
	@Column(name="topic")
	private String topic;
	@Column(name="duration")
	private String course_dura;
	@OneToMany(targetEntity = CourseTutr.class, cascade = {CascadeType.ALL})
	private List<CourseTutr> ctr ;	


	public Topics(){
		
	}
	
	public Topics(String topic,String course_dura)
	{
		super();
		this.topic = topic;
		this.course_dura = course_dura;
	}
	
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public String getCourse_dura() {
		return course_dura;
	}
	public void setCourse_dura(String course_dura) {
		this.course_dura = course_dura;
	}
	public List<CourseTutr> getCtr() {
		return ctr;
	}

	public void setCtr(List<CourseTutr> ctr) {
		this.ctr = ctr;
	}

}
