package com.maithu.springboothiber;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Topicservices {
	
	@Autowired
	private TopicRepository topicRepository;
	
	@Autowired
	private TutorRepository tutorRepository;
	
	//Topics tfortutoe = new Topics();
	
	/*private List<Topics> topicslist = (List<Topics>) new ArrayList<Topics>(Arrays.asList(new Topics("Java","30 days"),
																	new Topics("JSP","20 days"),
																	new Topics("Spring","41 days"))
			);
	*/
	
	public List<Topics> gettopics() {
		//return topicslist;
		List<Topics> topics =  new ArrayList<Topics>();
		topicRepository.findAll().forEach(topics::add);
		return topics;
	}
	
	public Optional<Topics> gettopicspecfic(String topic)
	{
		//return topicslist.stream().filter(p -> p.getTopic().equals(topic)).findFirst().get();
		
		return topicRepository.findById(topic);
		
	}
	
	public void addtopic(Topics topicname) {
		// TODO Auto-generated method stub
		//topicslist.add(topicname);	
		/*tfortutoe.setCourse_dura(topicname.getCourse_dura());
		tfortutoe.setTopic(topicname.getTopic());
		tfortutoe.setCtr(topicname.getCtr());*/
		topicRepository.save(topicname);
	}

	public void updatetopic(String id, Topics topic) {
	/*	Topics t;
		for(int i=0;i<topicslist.size();i++){
			t = topicslist.get(i);
			if(t.getTopic().equals(id)){
				topicslist.set(i, topic);
				return;
			}
		}*/
		topicRepository.save(topic);
		
	}

	public void deletetopic(String id) {
		//topicslist.removeIf(f -> f.getTopic().equals(id));
		//return;
		
		 topicRepository.deleteById(id);
	}
	
	public void addtutor(CourseTutr ct){
		
		tutorRepository.save(ct);		
	}
	
	public List findtutortopic(String tutrid){
		
		return topicRepository.findbyTutor(tutrid);	
	}

}
