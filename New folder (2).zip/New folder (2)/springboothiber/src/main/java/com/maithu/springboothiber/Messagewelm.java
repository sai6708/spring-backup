package com.maithu.springboothiber;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.maithu.springboothiber.Topics;
import com.maithu.springboothiber.Topicservices;

import java.util.List;
import java.util.Optional;

@RestController
public class Messagewelm {
	
	@Autowired
	private Topicservices tss;
	
	@RequestMapping("/hey") 
	public String wlcmes(ModelMap model) {
		model.put("result", "Hi, how u doing");
		return "welcome";
		
	}
	
	@RequestMapping(method = RequestMethod.GET,value="/topics")
	public List<Topics> Listoftopics() {
		System.out.println("Hey how's it going cool");
		return tss.gettopics();
		
	}
	
	@RequestMapping("/topics/{topicname}")
	public Optional<Topics> topic(@PathVariable String topicname) {
		
		return tss.gettopicspecfic(topicname);
		
	}
	
	@RequestMapping(method = RequestMethod.POST,value="/topics")
	public void addtopic(@RequestBody Topics topicname) {		
		 tss.addtopic(topicname);		
	}
	
	@RequestMapping(method = RequestMethod.PUT,value="/topics/{topicname}")
	public void Updatetopic(@RequestBody Topics topic,@PathVariable("topicname") String id) {		
		 tss.updatetopic(id, topic);		
	}
	
	@RequestMapping(method = RequestMethod.DELETE,value="/topics/{topicname}")
	public void deletetopic(@PathVariable("topicname") String id) {		
		 tss.deletetopic(id);		
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/tutor")
	public void addtutor(@RequestBody CourseTutr ctr){
		tss.addtutor(ctr);
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/tutortopic/{ctr}")
	public List<Object> tutortopic(@PathVariable String ctr){
		return tss.findtutortopic(ctr);
	}
}
