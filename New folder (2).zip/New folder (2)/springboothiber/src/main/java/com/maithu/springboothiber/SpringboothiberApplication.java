package com.maithu.springboothiber;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages={"com.maithu.repos", "com.maithu.springboothiber"})
@EnableAutoConfiguration
public class SpringboothiberApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringboothiberApplication.class, args);
	}

}
