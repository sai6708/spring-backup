package com.maithu.springboothiber;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;





public interface TopicRepository extends CrudRepository<Topics, String> {
	
	@Query(value= "select t.topic from topics t, topics_ctr ctr where ctr.topics_topic=t.topic and ctr.ctr_tid = :id", nativeQuery=true)
	List<Object> findbyTutor(@Param("id") String id);
	
}
