package com.maithu.springboothiber;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TutorRepository extends CrudRepository<CourseTutr, Integer> {

}
