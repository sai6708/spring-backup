package com.maithu.springboothiber;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class CourseTutr {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer tid;
	@Column
	private String tutour;
	
	
	public Integer getTid() {
		return tid;
	}
	public void setTid(Integer tid) {
		this.tid = tid;
	}
	
	public String getTutour() {
		return tutour;
	}
	public void setTutour(String tutour) {
		this.tutour = tutour;
	}

}
