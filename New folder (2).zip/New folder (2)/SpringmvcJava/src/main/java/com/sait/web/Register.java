package com.sait.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Register {
	
	@RequestMapping("add")
	public ModelAndView Useregister(@RequestParam("fname") String fname,@RequestParam("lname") String lname) {
		
		ModelAndView mv  = new ModelAndView();
		mv.addObject("result",fname+"  "+lname);
		mv.setViewName("resultview.jsp");
		return mv;
	}

}
