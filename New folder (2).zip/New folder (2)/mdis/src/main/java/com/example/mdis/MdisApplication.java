package com.example.mdis;

import java.util.Scanner;

public class MdisApplication {

	public static void main(String[] args) {
		
	}

}
