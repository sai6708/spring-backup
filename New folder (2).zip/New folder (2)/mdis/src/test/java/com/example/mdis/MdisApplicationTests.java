package com.example.mdis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MdisApplicationTests {

	@Test
	void contextLoads() {
	}

}
